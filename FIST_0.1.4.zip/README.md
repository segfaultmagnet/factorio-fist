# factorio-fist

Factorio mod which adds indirect fire support.

Includes Factorio-Stdlib (https://github.com/Afforess/Factorio-Stdlib).

## To-Do

Implement inventory for FDC and mortars.

Create queue with delays for projectile spawning.

Add round count selection.
