# factorio-fist

Factorio mod which adds indirect fire support.

Includes Factorio-Stdlib (https://github.com/Afforess/Factorio-Stdlib).

## To-Do

Clean up GUI: implement functions to add/remove TRP from list without requiring
a complete refresh.

Make better target_effect explosions.

Sprites!
