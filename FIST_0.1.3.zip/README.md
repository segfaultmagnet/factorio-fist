# factorio-fist

Factorio mod which adds indirect fire support.

Includes Factorio-Stdlib (https://github.com/Afforess/Factorio-Stdlib).

## To-Do

#### Clean up GUI:

  Make smaller replacement GUI on close so that fo-gun doesn't need to be fired in order to bring up controller.

  Add round type selection.

  Add round count selection.

#### Implement inventory for FDC and mortars.

#### Time in flight?
