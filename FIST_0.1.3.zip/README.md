# factorio-fist

Factorio mod which adds indirect fire support.

## To-Do

Fix mortar-60-he projectile.

Add explosion-gunshot entities at origin of gunshot.

Implement inventory for FDC and mortars.

Maybe change 60mm to 81mm?

Time in flight?
