# factorio-fist

Factorio mod which adds indirect fire support.

Includes Factorio-Stdlib (https://github.com/Afforess/Factorio-Stdlib).

## To-Do

Add round type selection.

Make smaller replacement GUI on close so that fo-gun doesn't need to be fired
in order to bring up controller.

Implement inventory for FDC and mortars.

Create queue with delays for projectile spawning.

Add round count selection.
