# factorio-fist

Factorio mod which adds indirect fire support.

## To-Do

Clean up GUI:

  Make smaller replacement GUI on close so that fo-gun doesn't need to be fired

    in order to bring up controller.

  Add round type selection.

  Add round count selection.

Implement inventory for FDC and mortars.

Maybe change 60mm to 81mm?

Time in flight?